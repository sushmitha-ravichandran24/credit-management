# Credit-Management
This app can be used to transfer credits from one user to another. Also,
records all transfers happened.
